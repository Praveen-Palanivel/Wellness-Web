import React, { useState, useEffect } from "react";
import {
  User,
  FileText,
  Download,
  Users,
  Bell,
  QrCode,
  Copy,
  Check,
  Edit3,
  Save,
  X
} from "lucide-react";

// Mock useLanguage hook for demo
const useLanguage = () => {
  const [language, setLanguage] = useState("en");
  return { language, setLanguage };
};

const translations = {
  en: {
    title: "Migrant Worker Dashboard",
    family: "Add Family Members",
    profile: "My Profile",
    records: "My Health Records",
    download: "Download Records",
    notifications: "Notifications",
    qrCode: "My QR Code",
    content: {
      welcome: "Welcome to your dashboard! Select an option from the navigation above.",
      family: "Add or manage your family members here.",
      records: "Access your health records here.",
      download: "Download your health records here.",
      notifications: "Check your notifications here.",
      qrCode: "Your unique QR code for health record access. Healthcare providers can scan this to view your records instantly."
    },
    qrTitle: "Your Health Record QR Code",
    qrSubtitle: "Show this QR code to healthcare providers for instant access to your medical records",
    copyId: "Copy ABHA ID",
    copied: "Copied!",
    scanInstructions: "Healthcare providers can scan this QR code to access your health records securely.",
    // Profile specific translations
    personalDetails: "Personal Details",
    addressDetails: "Address Details",
    stayingDetails: "Staying in Kerala Details",
    otherDetails: "Other Details",
    edit: "Edit",
    save: "Save",
    cancel: "Cancel",
    name: "Name",
    age: "Age",
    gender: "Gender",
    occupation: "Occupation",
    motherTongue: "Mother Tongue",
    nativeState: "Native State",
    nativeDistrict: "Native District",
    nativeAddress: "Native Address",
    district: "District",
    taluk: "Taluk",
    village: "Village",
    currentAddress: "Current Address",
    aadhaarNumber: "Aadhaar Number",
    employmentType: "Employment Type",
    aloOffice: "ALO Office",
    remarks: "Remarks",
    phone: "Phone Number"
  },
  hi: {
    title: "प्रवासी श्रमिक डैशबोर्ड",
    family: "परिवार के सदस्य जोड़ें",
    profile: "मेरी प्रोफाइल",
    records: "मेरे स्वास्थ्य रिकॉर्ड",
    download: "रिकॉर्ड डाउनलोड करें",
    notifications: "सूचनाएं",
    qrCode: "मेरा QR कोड",
    personalDetails: "व्यक्तिगत विवरण",
    addressDetails: "पता विवरण",
    stayingDetails: "केरल में रहने का विवरण",
    otherDetails: "अन्य विवरण",
    edit: "संपादित करें",
    save: "सहेजें",
    cancel: "रद्द करें",
    name: "नाम",
    age: "आयु",
    gender: "लिंग",
    occupation: "व्यवसाय",
    phone: "फोन नंबर"
  },
  ta: {
    title: "புலம்பெயர் தொழிலாளர் டாஷ்போர்டு",
    family: "குடும்ப உறுப்பினர்களைச் சேர்க்க",
    profile: "என் சுயவிவரம்",
    records: "என் சுகாதார பதிவுகள்",
    download: "பதிவுகளை பதிவிறக்கு",
    notifications: "அறிவிப்புகள்",
    qrCode: "என் QR குறியீடு",
    personalDetails: "தனிப்பட்ட விவரங்கள்",
    edit: "திருத்து",
    save: "சேமி",
    cancel: "ரத்து",
    name: "பெயர்",
    age: "வயது",
    phone: "தொலைபேசி எண்"
  }
};

// Generate QR Code URL using QR Server API
const generateQRCodeURL = (data) => {
  const encodedData = encodeURIComponent(data);
  const size = 200;
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodedData}`;
};

export default function MigrantWorkerHome() {
  const { language, setLanguage } = useLanguage();
  const [activeTab, setActiveTab] = useState("welcome");
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  // Mock authenticated user data
  const [authUser, setAuthUser] = useState({
    id: "123456789012",
    phone: "9876543210",
    role: "migrant",
    name: "SAM",
    age: "26",
    gender: "Male",
    occupation: "Construction Worker",
    motherTongue: "Tamil",
    nativeState: "Tamil Nadu",
    nativeDistrict: "Chennai",
    nativeAddress: "123 Main Street, Chennai",
    district: "Ernakulam",
    taluk: "Kochi",
    village: "Kakkanad",
    currentAddress: "456 Work Site, Kochi",
    aadhaarNumber: "1234-5678-9012",
    employmentType: "Daily Wage",
    aloOffice: "Ernakulam ALO",
    remarks: "Skilled worker"
  });

  const [editedProfile, setEditedProfile] = useState({...authUser});

  const qrData = authUser?.id ? `ABHA:${authUser.id}:HEALTH_RECORD_ACCESS` : '';
  const qrCodeURL = authUser?.id ? generateQRCodeURL(qrData) : null;

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedProfile({...authUser});
  };

  const handleSave = () => {
    setAuthUser({...editedProfile});
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedProfile({...authUser});
    setIsEditing(false);
  };

  const handleInputChange = (field, value) => {
    setEditedProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const ProfileSection = ({ title, children }) => (
    <div style={{
      backgroundColor: "#f8fafc",
      borderRadius: "12px",
      padding: "1.5rem",
      marginBottom: "1.5rem",
      border: "1px solid #e2e8f0"
    }}>
      <div style={{
        backgroundColor: "#a7f3d0",
        color: "#064e3b",
        padding: "0.75rem 1rem",
        borderRadius: "8px",
        marginBottom: "1rem",
        fontWeight: "600",
        fontSize: "1.1rem"
      }}>
        {title}
      </div>
      {children}
    </div>
  );

  const ProfileField = ({ label, field, type = "text" }) => (
    <div style={{ marginBottom: "1rem" }}>
      <label style={{
        display: "block",
        fontSize: "0.875rem",
        fontWeight: "500",
        color: "#374151",
        marginBottom: "0.25rem"
      }}>
        {label}
      </label>
      {isEditing ? (
        <input
          type={type}
          value={editedProfile[field] || ""}
          onChange={(e) => handleInputChange(field, e.target.value)}
          style={{
            width: "100%",
            padding: "0.5rem",
            border: "1px solid #d1d5db",
            borderRadius: "6px",
            fontSize: "0.875rem"
          }}
        />
      ) : (
        <div style={{
          padding: "0.5rem",
          backgroundColor: "white",
          border: "1px solid #e5e7eb",
          borderRadius: "6px",
          fontSize: "0.875rem",
          color: "#374151"
        }}>
          {authUser[field] || "Not specified"}
        </div>
      )}
    </div>
  );

  const QRCodeDisplay = ({ qrCodeURL }) => {
    if (!qrCodeURL) return null;
    
    return (
      <img 
        src={qrCodeURL}
        alt="Health Record QR Code"
        style={{ 
          width: '200px', 
          height: '200px',
          border: '1px solid #ccc',
          borderRadius: '8px'
        }}
        onError={(e) => {
          e.target.style.display = 'none';
          e.target.nextSibling.style.display = 'block';
        }}
      />
    );
  };

  const renderProfile = () => (
    <div style={{ maxWidth: "800px", margin: "0 auto", textAlign: "left" }}>
      <div style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "2rem"
      }}>
        <h2 style={{ color: "#1f2937", margin: 0 }}>
          {translations[language]?.profile || translations.en.profile}
        </h2>
        {!isEditing ? (
          <button
            onClick={handleEdit}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              padding: "0.5rem 1rem",
              backgroundColor: "#3b82f6",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer",
              fontSize: "0.875rem"
            }}
          >
            <Edit3 size={16} />
            {translations[language]?.edit || translations.en.edit}
          </button>
        ) : (
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              onClick={handleSave}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#10b981",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "0.875rem"
              }}
            >
              <Save size={16} />
              {translations[language]?.save || translations.en.save}
            </button>
            <button
              onClick={handleCancel}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#ef4444",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "0.875rem"
              }}
            >
              <X size={16} />
              {translations[language]?.cancel || translations.en.cancel}
            </button>
          </div>
        )}
      </div>

      <ProfileSection title={translations[language]?.personalDetails || translations.en.personalDetails}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
          <ProfileField label={translations[language]?.name || translations.en.name} field="name" />
          <ProfileField label={translations[language]?.phone || translations.en.phone} field="phone" />
          <ProfileField label={translations[language]?.age || translations.en.age} field="age" type="number" />
          <ProfileField label={translations[language]?.gender || translations.en.gender} field="gender" />
          <ProfileField label={translations[language]?.occupation || translations.en.occupation} field="occupation" />
          <ProfileField label={translations[language]?.motherTongue || translations.en.motherTongue} field="motherTongue" />
        </div>
      </ProfileSection>

      <ProfileSection title={translations[language]?.addressDetails || translations.en.addressDetails}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
          <ProfileField label={translations[language]?.nativeState || translations.en.nativeState} field="nativeState" />
          <ProfileField label={translations[language]?.nativeDistrict || translations.en.nativeDistrict} field="nativeDistrict" />
        </div>
        <ProfileField label={translations[language]?.nativeAddress || translations.en.nativeAddress} field="nativeAddress" />
      </ProfileSection>

      <ProfileSection title={translations[language]?.stayingDetails || translations.en.stayingDetails}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
          <ProfileField label={translations[language]?.district || translations.en.district} field="district" />
          <ProfileField label={translations[language]?.taluk || translations.en.taluk} field="taluk" />
        </div>
        <ProfileField label={translations[language]?.village || translations.en.village} field="village" />
        <ProfileField label={translations[language]?.currentAddress || translations.en.currentAddress} field="currentAddress" />
      </ProfileSection>

      <ProfileSection title={translations[language]?.otherDetails || translations.en.otherDetails}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
          <ProfileField label={translations[language]?.aadhaarNumber || translations.en.aadhaarNumber} field="aadhaarNumber" />
          <ProfileField label={translations[language]?.employmentType || translations.en.employmentType} field="employmentType" />
        </div>
        <ProfileField label={translations[language]?.aloOffice || translations.en.aloOffice} field="aloOffice" />
        <ProfileField label={translations[language]?.remarks || translations.en.remarks} field="remarks" />
      </ProfileSection>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case "family":
        return <p>{translations[language]?.content.family || translations.en.content.family}</p>;
      case "profile":
        return renderProfile();
      case "records":
        return <p>{translations[language]?.content.records || translations.en.content.records}</p>;
      case "download":
        return <p>{translations[language]?.content.download || translations.en.content.download}</p>;
      case "notifications":
        return <p>{translations[language]?.content.notifications || translations.en.content.notifications}</p>;
      case "qrcode":
        return (
          <div style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "1.5rem",
            maxWidth: "400px",
            margin: "0 auto",
            padding: "2rem",
            backgroundColor: "#f8fafc",
            borderRadius: "12px",
            border: "1px solid #e2e8f0"
          }}>
            <h2 style={{ color: "#1f2937", marginBottom: "0.5rem" }}>
              {translations[language]?.qrTitle || translations.en.qrTitle}
            </h2>
            <p style={{ color: "#6b7280", marginBottom: "1.5rem" }}>
              {translations[language]?.qrSubtitle || translations.en.qrSubtitle}
            </p>
            
            {qrCodeURL && (
              <div style={{
                backgroundColor: "white",
                padding: "1rem",
                borderRadius: "8px",
                border: "2px solid #e2e8f0"
              }}>
                <QRCodeDisplay qrCodeURL={qrCodeURL} />
              </div>
            )}
            
            {authUser && (
              <div style={{ 
                display: "flex", 
                alignItems: "center", 
                gap: "0.5rem",
                padding: "0.75rem 1rem",
                backgroundColor: "white",
                border: "1px solid #d1d5db",
                borderRadius: "6px",
                fontSize: "0.875rem"
              }}>
                <span style={{ fontWeight: "500" }}>ABHA ID: {authUser.id}</span>
                <button
                  onClick={() => copyToClipboard(authUser.id)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.25rem",
                    padding: "0.25rem 0.5rem",
                    backgroundColor: copied ? "#10b981" : "#3b82f6",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                    fontSize: "0.75rem",
                    transition: "background-color 0.2s"
                  }}
                >
                  {copied ? <Check size={12} /> : <Copy size={12} />}
                  {copied 
                    ? (translations[language]?.copied || translations.en.copied)
                    : (translations[language]?.copyId || translations.en.copyId)
                  }
                </button>
              </div>
            )}
          </div>
        );
      default:
        return <p>{translations[language]?.content.welcome || translations.en.content.welcome}</p>;
    }
  };

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#ffffff" }}>
      {/* Header */}
      <div style={{
        backgroundColor: "#2563eb",
        color: "white",
        padding: "1rem 2rem",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
      }}>
        <h1>{translations[language]?.title || translations.en.title}</h1>
        <select 
          style={{
            padding: '8px 12px',
            border: 'none',
            borderRadius: '6px',
            fontSize: '1rem',
            backgroundColor: 'white',
            color: '#374151'
          }} 
          value={language} 
          onChange={(e) => setLanguage(e.target.value)}
        >
          <option value="en">English</option>
          <option value="hi">हिंदी</option>
          <option value="ta">தமிழ்</option>
        </select>
      </div>

      {/* Authenticated User Info */}
      {authUser && authUser.role === 'migrant' && (
        <div style={{
          display: 'flex',
          gap: '2rem',
          alignItems: 'center',
          background: '#f0f5ff',
          border: '1px solid #d6e4ff',
          color: '#1d39c4',
          padding: '12px 16px',
          margin: '0 16px',
          borderRadius: '8px'
        }}>
          <div><strong>ABHA ID:</strong> {authUser.id}</div>
          <div><strong>Phone:</strong> {authUser.phone}</div>
        </div>
      )}

      {/* Navigation Bar */}
      <div style={{
        backgroundColor: "#f8fafc",
        borderBottom: "1px solid #e2e8f0",
        display: "flex",
        justifyContent: "space-around",
        alignItems: "center",
        flexWrap: "wrap"
      }}>
        {[
          { key: "family", icon: Users, color: "#10b981", label: translations[language]?.family || translations.en.family },
          { key: "profile", icon: User, color: "#3b82f6", label: translations[language]?.profile || translations.en.profile },
          { key: "records", icon: FileText, color: "#6366f1", label: translations[language]?.records || translations.en.records },
          { key: "download", icon: Download, color: "#8b5cf6", label: translations[language]?.download || translations.en.download },
          { key: "qrcode", icon: QrCode, color: "#f59e0b", label: translations[language]?.qrCode || translations.en.qrCode },
          { key: "notifications", icon: Bell, color: "#ef4444", label: translations[language]?.notifications || translations.en.notifications }
        ].map(({ key, icon: Icon, color, label }) => (
          <button
            key={key}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              padding: "1rem 0.5rem",
              cursor: "pointer",
              transition: "background-color 0.3s ease",
              minWidth: "100px",
              textAlign: "center",
              border: "none",
              backgroundColor: "transparent",
              color: "#374151",
              fontSize: "0.875rem",
              fontWeight: "500"
            }}
            onClick={() => setActiveTab(key)}
            onMouseEnter={(e) => (e.target.style.backgroundColor = "#e2e8f0")}
            onMouseLeave={(e) => (e.target.style.backgroundColor = "transparent")}
          >
            <Icon size={24} style={{ marginBottom: "0.5rem", color }} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* Main Content Area */}
      <div style={{ padding: "2rem", textAlign: "center" }}>{renderContent()}</div>
    </div>
  );
}