// import React, { useState } from "react";
// import './Authentication.css'
// import logo from '../images/wellnessweb_logo.png';
// import { useNavigate } from "react-router-dom";
// // import { useLanguage } from "../context/LanguageContext";
// // Dummy authentication data
// const DUMMY_USERS = {
//   migrant: {
//     id: "12345678901234", // 14-digit ABHA ID
//     phone: "9876543210",
//     password: "migrant123"
//   },
//   doctor: {
//     id: "DOC12345", // 8-character Health Professional ID
//     email: "doctor@example.com",
//     password: "doctor123",
//     name: "Dr. John Smith"
//   },
//   health: {
//     id: "HLT67890", // 8-character Health Professional ID
//     email: "health@example.com", 
//     password: "health123",
//     name: "Health Officer Jane"
//   }
// };

// function SocialButton({ children, onClick, isSelected }) {
//   return (
//     <button 
//       className={`social-btn ${isSelected ? 'selected' : ''}`}
//       onClick={onClick} 
//       type="button"
//     >
//       {children}
//     </button>
//   );
// }

// function OTPVerification({ onBack }) {
//   const [otp, setOtp] = useState(['', '', '', '']);

//   const handleOtpChange = (index, value) => {
//     if (isNaN(value)) return;
//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);
    
//     // Auto-focus next input
//     if (value && index < 3) {
//       const nextInput = document.getElementById(`otp-${index + 1}`);
//       nextInput?.focus();
//     }
//   };

//   const handleSubmit = () => {
//     console.log('OTP:', otp.join(''));
//   };

//   return (
//     <div className="form-container">
//       <div className="form">
//         <h2>Verify OTP</h2>
//         <p className="muted">Enter the OTP sent to your email/phone</p>
        
//         <div className="otp-container">
//           {[0,1,2,3].map((index) => (
//             <input
//               key={index}
//               id={`otp-${index}`}
//               type="text"
//               maxLength={1}
//               className="otp-input"
//               value={otp[index]}
//               onChange={(e) => handleOtpChange(index, e.target.value)}
//               autoFocus={index === 0}
//             />
//           ))}
//         </div>
        
//         <button type="button" onClick={handleSubmit} className="btn primary">Verify OTP</button>
//         <button type="button" className="btn ghost" onClick={onBack}>
//           Back to Login
//         </button>
//       </div>
//     </div>
//   );
// }

// function LoginForm({ setIsSignUpActive }) {
//   const [selectedRole, setSelectedRole] = useState('');
//   const [showOTP, setShowOTP] = useState(false);
//   const [isSignUp, setIsSignUp] = useState(false);
//   const [error, setError] = useState('');
//   const [success, setSuccess] = useState('');
//   const [currentPage, setCurrentPage] = useState('auth'); // For navigation
//   const [formData, setFormData] = useState({
//     id: '',
//     name: '',
//     emailOrPhone: '',
//     password: '',
//     confirmPassword: ''
//   });
//   // const { language, setLanguage } = useLanguage();
//   const navigate = useNavigate();

//   // Simple page routing
//   if (currentPage === 'migrant') {
//     navigate('/migrant');
//   }

//   if (currentPage === 'doctor') {
//     navigate("/doctor");
//   }

//   if (currentPage === 'health') {
//     navigate('/health');
//   }
  
//   // Clear form data when role changes
//   const handleRoleChange = (role) => {
//     setSelectedRole(role);
//     setError('');
//     setSuccess('');
//     setFormData({
//       id: '',
//       name: '',
//       emailOrPhone: '',
//       password: '',
//       confirmPassword: ''
//     });
//     if (role === 'migrant') {
//       setIsSignUp(false);
//     }
//   };

//   if (showOTP) {
//     return <OTPVerification onBack={() => setShowOTP(false)} />;
//   }

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setError('');
//     setSuccess('');

//     if (!selectedRole) {
//       setError('Please select a role first');
//       return;
//     }

//     if (isSignUp) {
//       // Handle registration
//       if (selectedRole !== 'migrant') {
//         if (formData.password !== formData.confirmPassword) {
//           setError('Passwords do not match');
//           return;
//         }
//         if (formData.password.length < 6) {
//           setError('Password must be at least 6 characters');
//           return;
//         }
//       }
//       setSuccess('Registration successful! You can now sign in.');
//       setIsSignUp(false);
//       // Clear form after successful registration
//       setFormData({
//         id: '',
//         name: '',
//         emailOrPhone: '',
//         password: '',
//         confirmPassword: ''
//       });
//     } else {
//       // Handle login with dummy data
//       const userData = DUMMY_USERS[selectedRole];
      
//       if (!userData) {
//         setError('Invalid role selected');
//         return;
//       }

//       // Check credentials
//       const isValidId = formData.id === userData.id;
//       const isValidContact = selectedRole === 'migrant' 
//         ? formData.emailOrPhone === userData.phone
//         : formData.emailOrPhone === userData.email;
//       const isValidPassword = formData.password === userData.password;

//       if (isValidId && isValidContact && isValidPassword) {
//         setSuccess('Login successful! Redirecting...');

//         // Persist minimal auth info for other pages to read
//         const authPayload = { ...userData, role: selectedRole };
//         try {
//           sessionStorage.setItem('authUser', JSON.stringify(authPayload));
//         } catch (e) {
//           console.warn('Unable to persist auth user in sessionStorage', e);
//         }
        
//         // Navigate to respective pages after a short delay
//         setTimeout(() => {
//           switch (selectedRole) {
//             case 'migrant':
//               setCurrentPage('migrant');
//               break;
//             case 'doctor':
//               setCurrentPage('doctor');
//               break;
//             case 'health':
//               setCurrentPage('health');
//               break;
//             default:
//               setError('Invalid role');
//           }
//         }, 1500);
//       } else {
//         setError('Invalid credentials. Please Check.');
//       }
//     }
//   };

//   return (
//     <div className="form-container sign-in-container">
//       <div className="form">
//         <br />
//         <div style={{ display: 'flex', justifyContent: 'left', alignItems: 'center', gap: '1rem' }}>
//           {isSignUp && selectedRole !== 'migrant' && (
//             <button 
//               type="button" 
//               className="back-btn"
//               onClick={() => setIsSignUp(false)}
//             >
//               Back
//             </button>
//           )}
//           <h2>{isSignUp ? 'Create Account' : 'Sign In'}</h2>
//         </div>

//         {/* Error/Success Messages */}
//         {error && (
//           <div style={{
//             padding: '10px',
//             backgroundColor: '#f8d7da',
//             border: '1px solid #f5c6cb',
//             borderRadius: '5px',
//             color: '#721c24',
//             marginBottom: '15px'
//           }}>
//             ❌ {error}
//           </div>
//         )}

//         {success && (
//           <div style={{
//             padding: '10px',
//             backgroundColor: '#d4edda',
//             border: '1px solid #c3e6cb',
//             borderRadius: '5px',
//             color: '#155724',
//             marginBottom: '15px'
//           }}>
//             ✅ {success}
//           </div>
//         )}
        
//         <div className="social-row">
//           <SocialButton 
//             onClick={() => handleRoleChange('migrant')}
//             isSelected={selectedRole === 'migrant'}
//           >
//             Migrant
//           </SocialButton>
//           <SocialButton 
//             onClick={() => handleRoleChange('doctor')}
//             isSelected={selectedRole === 'doctor'}
//           >
//             Doctor
//           </SocialButton>
//           <SocialButton 
//             onClick={() => handleRoleChange('health')}
//             isSelected={selectedRole === 'health'}
//           >
//             Health Official
//           </SocialButton>
//         </div>

//         {selectedRole && (
//           <div className="input-group">
//             <input 
//               type="text" 
//               required 
//               value={formData.id}
//               onChange={(e) => setFormData({...formData, id: e.target.value})}
//               placeholder={selectedRole === 'migrant' ? "ABHA ID" : "Health Professional ID"} 
//               pattern={selectedRole === 'migrant' ? "[0-9]{14}" : "[A-Z0-9]{8}"}
//               title={selectedRole === 'migrant' ? 
//                 "Please enter a valid 14-digit ABHA ID" : 
//                 "Please enter a valid 8-character Health Professional ID"
//               }
//               maxLength={selectedRole === 'migrant' ? 14 : 8}
//             />
//           </div>
//         )}

//         {/* Show Full Name field only for signup */}
//         {isSignUp && selectedRole !== 'migrant' && (
//           <input 
//             type="text" 
//             placeholder="Full Name" 
//             required 
//             value={formData.name}
//             onChange={(e) => setFormData({...formData, name: e.target.value})}
//           />
//         )}

//         <div className="input-group">
//           {selectedRole === 'migrant' ? (
//             <input 
//               type="tel" 
//               required 
//               placeholder="Phone Number" 
//               pattern="[0-9]{10}"
//               value={formData.emailOrPhone}
//               onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
//             />
//           ) : (
//             <input 
//               type="email" 
//               required 
//               placeholder="Email"
//               value={formData.emailOrPhone}
//               onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
//             />
//           )}
//         </div>
        
//         <input 
//           type="password" 
//           placeholder="Password"
//           required
//           value={formData.password}
//           onChange={(e) => setFormData({...formData, password: e.target.value})}
//         />
//         {isSignUp && selectedRole !== 'migrant' && (
//           <input 
//             type="password" 
//             placeholder="Confirm Password" 
//             required
//             value={formData.confirmPassword}
//             onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
//           />
//         )}

//         <div style={{ display: 'flex', justifyContent: "left", alignItems: 'center', gap: '1.5rem' }}>
//           {!isSignUp && (
//             <a className="link-muted" href="#" onClick={(e) => {
//               e.preventDefault();
//               setShowOTP(true);
//             }}>Forgot your password?</a>
//           )}
//           <button type="button" onClick={handleSubmit} className="btn primary">
//             {isSignUp ? 'Sign Up' : 'Sign In'}
//           </button>
//           {isSignUp && selectedRole !== 'migrant' && (
//             <a 
//               className="link-text" 
//               href="https://www.nmc.org.in/registration/" 
//               target="_blank"
//               rel="noopener noreferrer"
//             >
//               Don't have Health Professional ID?
//             </a>
//           )}
//         </div>

//         {selectedRole === 'migrant' ? (
//           <p className="switch-text">
//             Don't have an ABHA ID? <a className="link-text" href="https://abha.abdm.gov.in/abha/v3/register">Create One</a>
//           </p>
//         ) : (
//           <p className="switch-text">
//             {isSignUp ? 
//               "Already have an account? " : 
//               "Don't have an account? "
//             }
//             <span className="link-text" onClick={() => setIsSignUp(!isSignUp)}>
//               {isSignUp ? 'Sign In' : 'Sign Up'}
//             </span>
//           </p>
//         )}
//       </div>
//       <img src={logo} height={400} alt="WellnessWeb Logo" />
//     </div>
//   );
// }

// // BubbleEffect component (simplified version)
// function BubbleEffect() {
//   return (
//     <div className="bubble-container">
//       {/* Bubbles will be added via CSS animations */}
//     </div>
//   );
// }

// export default function Authentication() {
//   return (
//     <div className="page-bg">
//       <BubbleEffect />
//       <div className="auth-wrapper">
//         <div className="container">
//           <div className="form-wrap">
//             <LoginForm />
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }


// import React, { useState, createContext, useContext } from "react";
// import './Authentication.css'
// import logo from '../images/wellnessweb_logo.png';
// import { useNavigate } from "react-router-dom";

// // Language translations
// const translations = {
//   en: {
//     // Navigation and main titles
//     signIn: "Sign In",
//     createAccount: "Create Account",
//     back: "Back",
    
//     // Role buttons
//     migrant: "Migrant",
//     doctor: "Doctor",
//     healthOfficial: "Health Official",
    
//     // Form fields
//     abhaId: "ABHA ID",
//     healthProfessionalId: "Health Professional ID",
//     fullName: "Full Name",
//     phoneNumber: "Phone Number",
//     email: "Email",
//     password: "Password",
//     confirmPassword: "Confirm Password",
    
//     // Buttons and links
//     signUp: "Sign Up",
//     forgotPassword: "Forgot your password?",
//     dontHaveHealthId: "Don't have Health Professional ID?",
//     dontHaveAbhaId: "Don't have an ABHA ID?",
//     createOne: "Create One",
//     alreadyHaveAccount: "Already have an account?",
//     dontHaveAccount: "Don't have an account?",
    
//     // OTP
//     verifyOtp: "Verify OTP",
//     enterOtp: "Enter the OTP sent to your email/phone",
//     backToLogin: "Back to Login",
    
//     // Messages
//     selectRole: "Please select a role first",
//     passwordsDontMatch: "Passwords do not match",
//     passwordLength: "Password must be at least 6 characters",
//     registrationSuccess: "Registration successful! You can now sign in.",
//     invalidRole: "Invalid role selected",
//     invalidCredentials: "Invalid credentials. Please Check.",
//     loginSuccess: "Login successful! Redirecting...",
    
//     // Validation messages
//     validAbhaId: "Please enter a valid 14-digit ABHA ID",
//     validHealthId: "Please enter a valid 8-character Health Professional ID",
    
//     // Language selector
//     language: "Language",
//     english: "English",
//     malayalam: "മലയാളം",
//     tamil: "தமிழ்"
//   },
  
//   ml: {
//     // Navigation and main titles
//     signIn: "സൈൻ ഇൻ",
//     createAccount: "അക്കൗണ്ട് സൃഷ്ടിക്കുക",
//     back: "തിരികെ",
    
//     // Role buttons
//     migrant: "കുടിയേറ്റക്കാരൻ",
//     doctor: "ഡോക്ടർ",
//     healthOfficial: "ആരോഗ്യ ഉദ്യോഗസ്ഥൻ",
    
//     // Form fields
//     abhaId: "ABHA ഐഡി",
//     healthProfessionalId: "ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി",
//     fullName: "പൂർണ്ണ നാമം",
//     phoneNumber: "ഫോൺ നമ്പർ",
//     email: "ഇമെയിൽ",
//     password: "പാസ്‌വേഡ്",
//     confirmPassword: "പാസ്‌വേഡ് സ്ഥിരീകരിക്കുക",
    
//     // Buttons and links
//     signUp: "സൈൻ അപ്പ്",
//     forgotPassword: "പാസ്‌വേഡ് മറന്നോ?",
//     dontHaveHealthId: "ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി ഇല്ലേ?",
//     dontHaveAbhaId: "ABHA ഐഡി ഇല്ലേ?",
//     createOne: "ഒന്ന് സൃഷ്ടിക്കുക",
//     alreadyHaveAccount: "ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ?",
//     dontHaveAccount: "അക്കൗണ്ട് ഇല്ലേ?",
    
//     // OTP
//     verifyOtp: "OTP സ്ഥിരീകരിക്കുക",
//     enterOtp: "നിങ്ങളുടെ ഇമെയിൽ/ഫോണിലേക്ക് അയച്ച OTP നൽകുക",
//     backToLogin: "ലോഗിനിലേക്ക് തിരികെ",
    
//     // Messages
//     selectRole: "ആദ്യം ഒരു റോൾ തിരഞ്ഞെടുക്കുക",
//     passwordsDontMatch: "പാസ്‌വേഡുകൾ പൊരുത്തപ്പെടുന്നില്ല",
//     passwordLength: "പാസ്‌വേഡ് കുറഞ്ഞത് 6 അക്ഷരങ്ങൾ ആയിരിക്കണം",
//     registrationSuccess: "രജിസ്ട്രേഷൻ വിജയകരം! ഇപ്പോൾ സൈൻ ഇൻ ചെയ്യാം.",
//     invalidRole: "അസാധുവായ റോൾ തിരഞ്ഞെടുത്തു",
//     invalidCredentials: "അസാധുവായ ക്രെഡൻഷ്യലുകൾ. ദയവായി പരിശോധിക്കുക.",
//     loginSuccess: "ലോഗിൻ വിജയകരം! റീഡയറക്‌ട് ചെയ്യുന്നു...",
    
//     // Validation messages
//     validAbhaId: "സാധുവായ 14 അക്ക ABHA ഐഡി നൽകുക",
//     validHealthId: "സാധുവായ 8 അക്ഷര ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി നൽകുക",
    
//     // Language selector
//     language: "ഭാഷ",
//     english: "English",
//     malayalam: "മലയാളം",
//     tamil: "தமிழ்"
//   },
  
//   ta: {
//     // Navigation and main titles
//     signIn: "உள்நுழைக",
//     createAccount: "கணக்கை உருவாக்கு",
//     back: "திரும்பு",
    
//     // Role buttons
//     migrant: "புலம்பெயர்ந்தவர்",
//     doctor: "மருத்துவர்",
//     healthOfficial: "சுகாதார அலுவலர்",
    
//     // Form fields
//     abhaId: "ABHA ஐடி",
//     healthProfessionalId: "சுகாதார நிபுணர் ஐடி",
//     fullName: "முழு பெயர்",
//     phoneNumber: "தொலைபேசி எண்",
//     email: "மின்னஞ்சல்",
//     password: "கடவுச்சொல்",
//     confirmPassword: "கடவுச்சொல்லை உறுதிப்படுத்து",
    
//     // Buttons and links
//     signUp: "பதிவு செய்",
//     forgotPassword: "கடவுச்சொல்லை மறந்துவிட்டீர்களா?",
//     dontHaveHealthId: "சுகாதார நிபுணர் ஐடி இல்லையா?",
//     dontHaveAbhaId: "ABHA ஐடி இல்லையா?",
//     createOne: "ஒன்றை உருவாக்கு",
//     alreadyHaveAccount: "ஏற்கனவே கணக்கு உள்ளதா?",
//     dontHaveAccount: "கணக்கு இல்லையா?",
    
//     // OTP
//     verifyOtp: "OTP ஐ சரிபார்க்கவும்",
//     enterOtp: "உங்கள் மின்னஞ்சல்/தொலைபேசிக்கு அனுப்பப்பட்ட OTP ஐ உள்ளிடவும்",
//     backToLogin: "உள்நுழைவுக்கு திரும்பு",
    
//     // Messages
//     selectRole: "முதலில் ஒரு பாத்திரத்தை தேர்ந்தெடுக்கவும்",
//     passwordsDontMatch: "கடவுச்சொற்கள் பொருந்தவில்லை",
//     passwordLength: "கடவுச்சொல் குறைந்தது 6 எழுத்துக்களாக இருக்க வேண்டும்",
//     registrationSuccess: "பதிவு வெற்றிகரமாக! இப்போது உள்நுழையலாம்.",
//     invalidRole: "தவறான பாத்திரம் தேர்ந்தெடுக்கப்பட்டது",
//     invalidCredentials: "தவறான அறிமுக விவரங்கள். தயவுசெய்து சரிபார்க்கவும்.",
//     loginSuccess: "உள்நுழைவு வெற்றிகரமாக! திருப்பி விடுகிறது...",
    
//     // Validation messages
//     validAbhaId: "சரியான 14 இலக்க ABHA ஐடியை உள்ளிடவும்",
//     validHealthId: "சரியான 8 எழுத்து சுகாதார நிபுணர் ஐடியை உள்ளிடவும்",
    
//     // Language selector
//     language: "மொழி",
//     english: "English",
//     malayalam: "മലയാളം",
//     tamil: "தமிழ்"
//   }
// };

// // Language Context
// const LanguageContext = createContext();

// export const useLanguage = () => {
//   const context = useContext(LanguageContext);
//   if (!context) {
//     throw new Error('useLanguage must be used within a LanguageProvider');
//   }
//   return context;
// };

// function LanguageProvider({ children }) {
//   const [language, setLanguage] = useState('en');
  
//   const t = (key) => {
//     return translations[language][key] || key;
//   };
  
//   return (
//     <LanguageContext.Provider value={{ language, setLanguage, t }}>
//       {children}
//     </LanguageContext.Provider>
//   );
// }

// // Language Selector Component
// function LanguageSelector() {
//   const { language, setLanguage, t } = useLanguage();
  
//   return (
//     <div style={{
//       position: 'absolute',
//       top: '20px',
//       right: '20px',
//       zIndex: 1000
//     }}>
//       <select 
//         value={language}
//         onChange={(e) => setLanguage(e.target.value)}
//         style={{
//           padding: '8px 12px',
//           borderRadius: '5px',
//           border: '1px solid #ddd',
//           backgroundColor: 'white',
//           fontSize: '14px',
//           cursor: 'pointer'
//         }}
//       >
//         <option value="en">{t('english')}</option>
//         <option value="ml">{t('malayalam')}</option>
//         <option value="ta">{t('tamil')}</option>
//       </select>
//     </div>
//   );
// }

// // Dummy authentication data (unchanged)
// const DUMMY_USERS = {
//   migrant: {
//     id: "12345678901234", // 14-digit ABHA ID
//     phone: "9876543210",
//     password: "migrant123"
//   },
//   doctor: {
//     id: "DOC12345", // 8-character Health Professional ID
//     email: "doctor@example.com",
//     password: "doctor123",
//     name: "Dr. John Smith"
//   },
//   health: {
//     id: "HLT67890", // 8-character Health Professional ID
//     email: "health@example.com", 
//     password: "health123",
//     name: "Health Officer Jane"
//   }
// };

// function SocialButton({ children, onClick, isSelected }) {
//   return (
//     <button 
//       className={`social-btn ${isSelected ? 'selected' : ''}`}
//       onClick={onClick} 
//       type="button"
//     >
//       {children}
//     </button>
//   );
// }

// function OTPVerification({ onBack }) {
//   const { t } = useLanguage();
//   const [otp, setOtp] = useState(['', '', '', '']);

//   const handleOtpChange = (index, value) => {
//     if (isNaN(value)) return;
//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);
    
//     // Auto-focus next input
//     if (value && index < 3) {
//       const nextInput = document.getElementById(`otp-${index + 1}`);
//       nextInput?.focus();
//     }
//   };

//   const handleSubmit = () => {
//     console.log('OTP:', otp.join(''));
//   };

//   return (
//     <div className="form-container">
//       <div className="form">
//         <h2>{t('verifyOtp')}</h2>
//         <p className="muted">{t('enterOtp')}</p>
        
//         <div className="otp-container">
//           {[0,1,2,3].map((index) => (
//             <input
//               key={index}
//               id={`otp-${index}`}
//               type="text"
//               maxLength={1}
//               className="otp-input"
//               value={otp[index]}
//               onChange={(e) => handleOtpChange(index, e.target.value)}
//               autoFocus={index === 0}
//             />
//           ))}
//         </div>
        
//         <button type="button" onClick={handleSubmit} className="btn primary">
//           {t('verifyOtp')}
//         </button>
//         <button type="button" className="btn ghost" onClick={onBack}>
//           {t('backToLogin')}
//         </button>
//       </div>
//     </div>
//   );
// }

// function LoginForm({ setIsSignUpActive }) {
//   const { t } = useLanguage();
//   const [selectedRole, setSelectedRole] = useState('');
//   const [showOTP, setShowOTP] = useState(false);
//   const [isSignUp, setIsSignUp] = useState(false);
//   const [error, setError] = useState('');
//   const [success, setSuccess] = useState('');
//   const [currentPage, setCurrentPage] = useState('auth'); // For navigation
//   const [formData, setFormData] = useState({
//     id: '',
//     name: '',
//     emailOrPhone: '',
//     password: '',
//     confirmPassword: ''
//   });
  
//   const navigate = useNavigate();

//   // Simple page routing
//   if (currentPage === 'migrant') {
//     navigate('/migrant');
//   }

//   if (currentPage === 'doctor') {
//     navigate("/doctor");
//   }

//   if (currentPage === 'health') {
//     navigate('/health');
//   }
  
//   // Clear form data when role changes
//   const handleRoleChange = (role) => {
//     setSelectedRole(role);
//     setError('');
//     setSuccess('');
//     setFormData({
//       id: '',
//       name: '',
//       emailOrPhone: '',
//       password: '',
//       confirmPassword: ''
//     });
//     if (role === 'migrant') {
//       setIsSignUp(false);
//     }
//   };

//   if (showOTP) {
//     return <OTPVerification onBack={() => setShowOTP(false)} />;
//   }

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setError('');
//     setSuccess('');

//     if (!selectedRole) {
//       setError(t('selectRole'));
//       return;
//     }

//     if (isSignUp) {
//       // Handle registration
//       if (selectedRole !== 'migrant') {
//         if (formData.password !== formData.confirmPassword) {
//           setError(t('passwordsDontMatch'));
//           return;
//         }
//         if (formData.password.length < 6) {
//           setError(t('passwordLength'));
//           return;
//         }
//       }
//       setSuccess(t('registrationSuccess'));
//       setIsSignUp(false);
//       // Clear form after successful registration
//       setFormData({
//         id: '',
//         name: '',
//         emailOrPhone: '',
//         password: '',
//         confirmPassword: ''
//       });
//     } else {
//       // Handle login with dummy data
//       const userData = DUMMY_USERS[selectedRole];
      
//       if (!userData) {
//         setError(t('invalidRole'));
//         return;
//       }

//       // Check credentials
//       const isValidId = formData.id === userData.id;
//       const isValidContact = selectedRole === 'migrant' 
//         ? formData.emailOrPhone === userData.phone
//         : formData.emailOrPhone === userData.email;
//       const isValidPassword = formData.password === userData.password;

//       if (isValidId && isValidContact && isValidPassword) {
//         setSuccess(t('loginSuccess'));

//         // Persist minimal auth info for other pages to read
//         const authPayload = { ...userData, role: selectedRole };
//         try {
//           sessionStorage.setItem('authUser', JSON.stringify(authPayload));
//         } catch (e) {
//           console.warn('Unable to persist auth user in sessionStorage', e);
//         }
        
//         // Navigate to respective pages after a short delay
//         setTimeout(() => {
//           switch (selectedRole) {
//             case 'migrant':
//               setCurrentPage('migrant');
//               break;
//             case 'doctor':
//               setCurrentPage('doctor');
//               break;
//             case 'health':
//               setCurrentPage('health');
//               break;
//             default:
//               setError(t('invalidRole'));
//           }
//         }, 1500);
//       } else {
//         setError(t('invalidCredentials'));
//       }
//     }
//   };

//   return (
//     <div className="form-container sign-in-container">
//       <div className="form">
//         <br />
//         <div style={{ display: 'flex', justifyContent: 'left', alignItems: 'center', gap: '1rem' }}>
//           {isSignUp && selectedRole !== 'migrant' && (
//             <button 
//               type="button" 
//               className="back-btn"
//               onClick={() => setIsSignUp(false)}
//             >
//               {t('back')}
//             </button>
//           )}
//           <h2>{isSignUp ? t('createAccount') : t('signIn')}</h2>
//         </div>

//         {/* Error/Success Messages */}
//         {error && (
//           <div style={{
//             padding: '10px',
//             backgroundColor: '#f8d7da',
//             border: '1px solid #f5c6cb',
//             borderRadius: '5px',
//             color: '#721c24',
//             marginBottom: '15px'
//           }}>
//             ❌ {error}
//           </div>
//         )}

//         {success && (
//           <div style={{
//             padding: '10px',
//             backgroundColor: '#d4edda',
//             border: '1px solid #c3e6cb',
//             borderRadius: '5px',
//             color: '#155724',
//             marginBottom: '15px'
//           }}>
//             ✅ {success}
//           </div>
//         )}
        
//         <div className="social-row">
//           <SocialButton 
//             onClick={() => handleRoleChange('migrant')}
//             isSelected={selectedRole === 'migrant'}
//           >
//             {t('migrant')}
//           </SocialButton>
//           <SocialButton 
//             onClick={() => handleRoleChange('doctor')}
//             isSelected={selectedRole === 'doctor'}
//           >
//             {t('doctor')}
//           </SocialButton>
//           <SocialButton 
//             onClick={() => handleRoleChange('health')}
//             isSelected={selectedRole === 'health'}
//           >
//             {t('healthOfficial')}
//           </SocialButton>
//         </div>

//         {selectedRole && (
//           <div className="input-group">
//             <input 
//               type="text" 
//               required 
//               value={formData.id}
//               onChange={(e) => setFormData({...formData, id: e.target.value})}
//               placeholder={selectedRole === 'migrant' ? t('abhaId') : t('healthProfessionalId')} 
//               pattern={selectedRole === 'migrant' ? "[0-9]{14}" : "[A-Z0-9]{8}"}
//               title={selectedRole === 'migrant' ? 
//                 t('validAbhaId') : 
//                 t('validHealthId')
//               }
//               maxLength={selectedRole === 'migrant' ? 14 : 8}
//             />
//           </div>
//         )}

//         {/* Show Full Name field only for signup */}
//         {isSignUp && selectedRole !== 'migrant' && (
//           <input 
//             type="text" 
//             placeholder={t('fullName')} 
//             required 
//             value={formData.name}
//             onChange={(e) => setFormData({...formData, name: e.target.value})}
//           />
//         )}

//         <div className="input-group">
//           {selectedRole === 'migrant' ? (
//             <input 
//               type="tel" 
//               required 
//               placeholder={t('phoneNumber')} 
//               pattern="[0-9]{10}"
//               value={formData.emailOrPhone}
//               onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
//             />
//           ) : (
//             <input 
//               type="email" 
//               required 
//               placeholder={t('email')}
//               value={formData.emailOrPhone}
//               onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
//             />
//           )}
//         </div>
        
//         <input 
//           type="password" 
//           placeholder={t('password')}
//           required
//           value={formData.password}
//           onChange={(e) => setFormData({...formData, password: e.target.value})}
//         />
//         {isSignUp && selectedRole !== 'migrant' && (
//           <input 
//             type="password" 
//             placeholder={t('confirmPassword')} 
//             required
//             value={formData.confirmPassword}
//             onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
//           />
//         )}

//         <div style={{ display: 'flex', justifyContent: "left", alignItems: 'center', gap: '1.5rem' }}>
//           {!isSignUp && (
//             <a className="link-muted" href="#" onClick={(e) => {
//               e.preventDefault();
//               setShowOTP(true);
//             }}>{t('forgotPassword')}</a>
//           )}
//           <button type="button" onClick={handleSubmit} className="btn primary">
//             {isSignUp ? t('signUp') : t('signIn')}
//           </button>
//           {isSignUp && selectedRole !== 'migrant' && (
//             <a 
//               className="link-text" 
//               href="https://www.nmc.org.in/registration/" 
//               target="_blank"
//               rel="noopener noreferrer"
//             >
//               {t('dontHaveHealthId')}
//             </a>
//           )}
//         </div>

//         {selectedRole === 'migrant' ? (
//           <p className="switch-text">
//             {t('dontHaveAbhaId')} <a className="link-text" href="https://abha.abdm.gov.in/abha/v3/register">{t('createOne')}</a>
//           </p>
//         ) : (
//           <p className="switch-text">
//             {isSignUp ? 
//               t('alreadyHaveAccount') + " " : 
//               t('dontHaveAccount') + " "
//             }
//             <span className="link-text" onClick={() => setIsSignUp(!isSignUp)}>
//               {isSignUp ? t('signIn') : t('signUp')}
//             </span>
//           </p>
//         )}
//       </div>
//       <img src={logo} height={400} alt="WellnessWeb Logo" />
//     </div>
//   );
// }

// // BubbleEffect component (simplified version)
// function BubbleEffect() {
//   return (
//     <div className="bubble-container">
//       {/* Bubbles will be added via CSS animations */}
//     </div>
//   );
// }

// export default function Authentication() {
//   return (
//     <LanguageProvider>
//       <div className="page-bg">
//         <LanguageSelector />
//         <BubbleEffect />
//         <div className="auth-wrapper">
//           <div className="container">
//             <div className="form-wrap">
//               <LoginForm />
//             </div>
//           </div>
//         </div>
//       </div>
//     </LanguageProvider>
//   );
// }

import React, { useState } from "react";
import './Authentication.css'
import logo from '../images/wellnessweb_logo.png';
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../context/LanguageContext";

// Language translations
const translations = {
  en: {
    // Navigation and main titles
    signIn: "Sign In",
    createAccount: "Create Account",
    back: "Back",
    
    // Role buttons
    migrant: "Migrant",
    doctor: "Doctor",
    healthOfficial: "Health Official",
    
    // Form fields
    abhaId: "ABHA ID",
    healthProfessionalId: "Health Professional ID",
    fullName: "Full Name",
    phoneNumber: "Phone Number",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm Password",
    
    // Buttons and links
    signUp: "Sign Up",
    forgotPassword: "Forgot your password?",
    dontHaveHealthId: "Don't have Health Professional ID?",
    dontHaveAbhaId: "Don't have an ABHA ID?",
    createOne: "Create One",
    alreadyHaveAccount: "Already have an account?",
    dontHaveAccount: "Don't have an account?",
    
    // OTP
    verifyOtp: "Verify OTP",
    enterOtp: "Enter the OTP sent to your email/phone",
    backToLogin: "Back to Login",
    
    // Messages
    selectRole: "Please select a role first",
    passwordsDontMatch: "Passwords do not match",
    passwordLength: "Password must be at least 6 characters",
    registrationSuccess: "Registration successful! You can now sign in.",
    invalidRole: "Invalid role selected",
    invalidCredentials: "Invalid credentials. Please Check.",
    loginSuccess: "Login successful! Redirecting...",
    
    // Validation messages
    validAbhaId: "Please enter a valid 14-digit ABHA ID",
    validHealthId: "Please enter a valid 8-character Health Professional ID",
    
    // Language selector
    language: "Language",
    english: "English",
    malayalam: "മലയാളം",
    tamil: "தமிழ்",
    hindi: "हिंदी"
  },
  
  hi: {
    // Navigation and main titles
    signIn: "साइन इन",
    createAccount: "खाता बनाएं",
    back: "वापस",
    
    // Role buttons
    migrant: "प्रवासी",
    doctor: "डॉक्टर",
    healthOfficial: "स्वास्थ्य अधिकारी",
    
    // Form fields
    abhaId: "ABHA आईडी",
    healthProfessionalId: "स्वास्थ्य पेशेवर आईडी",
    fullName: "पूरा नाम",
    phoneNumber: "फोन नंबर",
    email: "ईमेल",
    password: "पासवर्ड",
    confirmPassword: "पासवर्ड की पुष्टि करें",
    
    // Buttons and links
    signUp: "साइन अप",
    forgotPassword: "पासवर्ड भूल गए?",
    dontHaveHealthId: "स्वास्थ्य पेशेवर आईडी नहीं है?",
    dontHaveAbhaId: "ABHA आईडी नहीं है?",
    createOne: "एक बनाएं",
    alreadyHaveAccount: "क्या आपके पास पहले से खाता है?",
    dontHaveAccount: "कोई खाता नहीं है?",
    
    // OTP
    verifyOtp: "OTP सत्यापित करें",
    enterOtp: "आपके ईमेल/फोन पर भेजा गया OTP दर्ज करें",
    backToLogin: "लॉगिन पर वापस जाएं",
    
    // Messages
    selectRole: "कृपया पहले एक भूमिका चुनें",
    passwordsDontMatch: "पासवर्ड मेल नहीं खाते",
    passwordLength: "पासवर्ड कम से कम 6 अक्षर का होना चाहिए",
    registrationSuccess: "पंजीकरण सफल! अब आप साइन इन कर सकते हैं।",
    invalidRole: "अमान्य भूमिका चुनी गई",
    invalidCredentials: "अमान्य क्रेडेंशियल। कृपया जांचें।",
    loginSuccess: "लॉगिन सफल! पुनर्निर्देशित हो रहे हैं...",
    
    // Validation messages
    validAbhaId: "कृपया एक वैध 14-अंकीय ABHA आईडी दर्ज करें",
    validHealthId: "कृपया एक वैध 8-वर्ण स्वास्थ्य पेशेवर आईडी दर्ज करें",
    
    // Language selector
    language: "भाषा",
    english: "English",
    malayalam: "മലയാളം",
    tamil: "தமிழ்",
    hindi: "हिंदी"
  },
  
  ml: {
    // Navigation and main titles
    signIn: "സൈൻ ഇൻ",
    createAccount: "അക്കൗണ്ട് സൃഷ്ടിക്കുക",
    back: "തിരികെ",
    
    // Role buttons
    migrant: "കുടിയേറ്റക്കാരൻ",
    doctor: "ഡോക്ടർ",
    healthOfficial: "ആരോഗ്യ ഉദ്യോഗസ്ഥൻ",
    
    // Form fields
    abhaId: "ABHA ഐഡി",
    healthProfessionalId: "ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി",
    fullName: "പൂർണ്ണ നാമം",
    phoneNumber: "ഫോൺ നമ്പർ",
    email: "ഇമെയിൽ",
    password: "പാസ്‌വേഡ്",
    confirmPassword: "പാസ്‌വേഡ് സ്ഥിരീകരിക്കുക",
    
    // Buttons and links
    signUp: "സൈൻ അപ്പ്",
    forgotPassword: "പാസ്‌വേഡ് മറന്നോ?",
    dontHaveHealthId: "ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി ഇല്ലേ?",
    dontHaveAbhaId: "ABHA ഐഡി ഇല്ലേ?",
    createOne: "ഒന്ന് സൃഷ്ടിക്കുക",
    alreadyHaveAccount: "ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ?",
    dontHaveAccount: "അക്കൗണ്ട് ഇല്ലേ?",
    
    // OTP
    verifyOtp: "OTP സ്ഥിരീകരിക്കുക",
    enterOtp: "നിങ്ങളുടെ ഇമെയിൽ/ഫോണിലേക്ക് അയച്ച OTP നൽകുക",
    backToLogin: "ലോഗിനിലേക്ക് തിരികെ",
    
    // Messages
    selectRole: "ആദ്യം ഒരു റോൾ തിരഞ്ഞെടുക്കുക",
    passwordsDontMatch: "പാസ്‌വേഡുകൾ പൊരുത്തപ്പെടുന്നില്ല",
    passwordLength: "പാസ്‌വേഡ് കുറഞ്ഞത് 6 അക്ഷരങ്ങൾ ആയിരിക്കണം",
    registrationSuccess: "രജിസ്ട്രേഷൻ വിജയകരം! ഇപ്പോൾ സൈൻ ഇൻ ചെയ്യാം.",
    invalidRole: "അസാധുവായ റോൾ തിരഞ്ഞെടുത്തു",
    invalidCredentials: "അസാധുവായ ക്രെഡൻഷ്യലുകൾ. ദയവായി പരിശോധിക്കുക.",
    loginSuccess: "ലോഗിൻ വിജയകരം! റീഡയറക്‌ട് ചെയ്യുന്നു...",
    
    // Validation messages
    validAbhaId: "സാധുവായ 14 അക്ക ABHA ഐഡി നൽകുക",
    validHealthId: "സാധുവായ 8 അക്ഷര ആരോഗ്യ പ്രൊഫഷണൽ ഐഡി നൽകുക",
    
    // Language selector
    language: "ഭാഷ",
    english: "English",
    malayalam: "മലയാളം",
    tamil: "தமிழ்",
    hindi: "हिंदी"
  },
  
  ta: {
    // Navigation and main titles
    signIn: "உள்நுழைக",
    createAccount: "கணக்கை உருவாக்கு",
    back: "திரும்பு",
    
    // Role buttons
    migrant: "புலம்பெயர்ந்தவர்",
    doctor: "மருத்துவர்",
    healthOfficial: "சுகாதார அலுவலர்",
    
    // Form fields
    abhaId: "ABHA ஐடி",
    healthProfessionalId: "சுகாதார நிபுணர் ஐடி",
    fullName: "முழு பெயர்",
    phoneNumber: "தொலைபேசி எண்",
    email: "மின்னஞ்சல்",
    password: "கடவுச்சொல்",
    confirmPassword: "கடவுச்சொல்லை உறுதிப்படுத்து",
    
    // Buttons and links
    signUp: "பதிவு செய்",
    forgotPassword: "கடவுச்சொல்லை மறந்துவிட்டீர்களா?",
    dontHaveHealthId: "சுகாதார நிபுணர் ஐடி இல்லையா?",
    dontHaveAbhaId: "ABHA ஐடி இல்லையா?",
    createOne: "ஒன்றை உருவாக்கு",
    alreadyHaveAccount: "ஏற்கனவே கணக்கு உள்ளதா?",
    dontHaveAccount: "கணக்கு இல்லையா?",
    
    // OTP
    verifyOtp: "OTP ஐ சரிபார்க்கவும்",
    enterOtp: "உங்கள் மின்னஞ்சல்/தொலைபேசிக்கு அனுப்பப்பட்ட OTP ஐ உள்ளிடவும்",
    backToLogin: "உள்நுழைவுக்கு திரும்பு",
    
    // Messages
    selectRole: "முதலில் ஒரு பாத்திரத்தை தேர்ந்தெடுக்கவும்",
    passwordsDontMatch: "கடவுச்சொற்கள் பொருந்தவில்லை",
    passwordLength: "கடவுச்சொல் குறைந்தது 6 எழுத்துக்களாக இருக்க வேண்டும்",
    registrationSuccess: "பதிவு வெற்றிகரமாக! இப்போது உள்நுழையலாம்.",
    invalidRole: "தவறான பாத்திரம் தேர்ந்தெடுக்கப்பட்டது",
    invalidCredentials: "தவறான அறிமுக விவரங்கள். தயவுசெய்து சரிபார்க்கவும்.",
    loginSuccess: "உள்நுழைவு வெற்றிகரமாக! திருப்பி விடுகிறது...",
    
    // Validation messages
    validAbhaId: "சரியான 14 இலக்க ABHA ஐடியை உள்ளிடவும்",
    validHealthId: "சரியான 8 எழுத்து சுகாதார நிபுணர் ஐடியை உள்ளிடவும்",
    
    // Language selector
    language: "மொழி",
    english: "English",
    malayalam: "മലയാളം",
    tamil: "தமிழ்",
    hindi: "हिंदी"
  }
};

// Language Selector Component
function LanguageSelector() {
  const { language, setLanguage } = useLanguage();
  
  // Map context language codes to display labels
  const languageLabels = {
    en: "English",
    hi: "हिंदी", 
    ta: "தமிழ்",
    ml: "മലയാളം"
  };
  
  return (
    <div style={{
      position: 'absolute',
      top: '20px',
      right: '20px',
      zIndex: 1000
    }}>
      <select 
        value={language}
        onChange={(e) => setLanguage(e.target.value)}
        style={{
          padding: '8px 12px',
          borderRadius: '5px',
          border: '1px solid #ddd',
          backgroundColor: 'white',
          fontSize: '14px',
          cursor: 'pointer'
        }}
      >
        <option value="en">{languageLabels.en}</option>
        <option value="hi">{languageLabels.hi}</option>
        <option value="ta">{languageLabels.ta}</option>
        <option value="ml">{languageLabels.ml}</option>
      </select>
    </div>
  );
}

// Dummy authentication data (unchanged)
const DUMMY_USERS = {
  migrant: {
    id: "12345678901234", // 14-digit ABHA ID
    phone: "9876543210",
    password: "migrant123"
  },
  doctor: {
    id: "DOC12345", // 8-character Health Professional ID
    email: "doctor@example.com",
    password: "doctor123",
    name: "Dr. John Smith"
  },
  health: {
    id: "HLT67890", // 8-character Health Professional ID
    email: "health@example.com", 
    password: "health123",
    name: "Health Officer Jane"
  }
};

function SocialButton({ children, onClick, isSelected }) {
  return (
    <button 
      className={`social-btn ${isSelected ? 'selected' : ''}`}
      onClick={onClick} 
      type="button"
    >
      {children}
    </button>
  );
}

function OTPVerification({ onBack }) {
  const { language } = useLanguage();
  const [otp, setOtp] = useState(['', '', '', '']);

  // Get translation function
  const t = (key) => {
    return translations[language][key] || key;
  };

  const handleOtpChange = (index, value) => {
    if (isNaN(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto-focus next input
    if (value && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleSubmit = () => {
    console.log('OTP:', otp.join(''));
  };

  return (
    <div className="form-container">
      <div className="form">
        <h2>{t('verifyOtp')}</h2>
        <p className="muted">{t('enterOtp')}</p>
        
        <div className="otp-container">
          {[0,1,2,3].map((index) => (
            <input
              key={index}
              id={`otp-${index}`}
              type="text"
              maxLength={1}
              className="otp-input"
              value={otp[index]}
              onChange={(e) => handleOtpChange(index, e.target.value)}
              autoFocus={index === 0}
            />
          ))}
        </div>
        
        <button type="button" onClick={handleSubmit} className="btn primary">
          {t('verifyOtp')}
        </button>
        <button type="button" className="btn ghost" onClick={onBack}>
          {t('backToLogin')}
        </button>
      </div>
    </div>
  );
}

function LoginForm({ setIsSignUpActive }) {
  const { language } = useLanguage();
  const [selectedRole, setSelectedRole] = useState('');
  const [showOTP, setShowOTP] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [currentPage, setCurrentPage] = useState('auth'); // For navigation
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    emailOrPhone: '',
    password: '',
    confirmPassword: ''
  });
  
  const navigate = useNavigate();

  // Get translation function
  const t = (key) => {
    return translations[language][key] || key;
  };

  // Simple page routing
  if (currentPage === 'migrant') {
    navigate('/migrant');
  }

  if (currentPage === 'doctor') {
    navigate("/doctor");
  }

  if (currentPage === 'health') {
    navigate('/health');
  }
  
  // Clear form data when role changes
  const handleRoleChange = (role) => {
    setSelectedRole(role);
    setError('');
    setSuccess('');
    setFormData({
      id: '',
      name: '',
      emailOrPhone: '',
      password: '',
      confirmPassword: ''
    });
    if (role === 'migrant') {
      setIsSignUp(false);
    }
  };

  if (showOTP) {
    return <OTPVerification onBack={() => setShowOTP(false)} />;
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!selectedRole) {
      setError(t('selectRole'));
      return;
    }

    if (isSignUp) {
      // Handle registration
      if (selectedRole !== 'migrant') {
        if (formData.password !== formData.confirmPassword) {
          setError(t('passwordsDontMatch'));
          return;
        }
        if (formData.password.length < 6) {
          setError(t('passwordLength'));
          return;
        }
      }
      setSuccess(t('registrationSuccess'));
      setIsSignUp(false);
      // Clear form after successful registration
      setFormData({
        id: '',
        name: '',
        emailOrPhone: '',
        password: '',
        confirmPassword: ''
      });
    } else {
      // Handle login with dummy data
      const userData = DUMMY_USERS[selectedRole];
      
      if (!userData) {
        setError(t('invalidRole'));
        return;
      }

      // Check credentials
      const isValidId = formData.id === userData.id;
      const isValidContact = selectedRole === 'migrant' 
        ? formData.emailOrPhone === userData.phone
        : formData.emailOrPhone === userData.email;
      const isValidPassword = formData.password === userData.password;

      if (isValidId && isValidContact && isValidPassword) {
        setSuccess(t('loginSuccess'));

        // Persist minimal auth info for other pages to read
        const authPayload = { ...userData, role: selectedRole };
        try {
          sessionStorage.setItem('authUser', JSON.stringify(authPayload));
        } catch (e) {
          console.warn('Unable to persist auth user in sessionStorage', e);
        }
        
        // Navigate to respective pages after a short delay
        setTimeout(() => {
          switch (selectedRole) {
            case 'migrant':
              setCurrentPage('migrant');
              break;
            case 'doctor':
              setCurrentPage('doctor');
              break;
            case 'health':
              setCurrentPage('health');
              break;
            default:
              setError(t('invalidRole'));
          }
        }, 1500);
      } else {
        setError(t('invalidCredentials'));
      }
    }
  };

  return (
    <div className="form-container sign-in-container">
      <div className="form">
        <br />
        <div style={{ display: 'flex', justifyContent: 'left', alignItems: 'center', gap: '1rem' }}>
          {isSignUp && selectedRole !== 'migrant' && (
            <button 
              type="button" 
              className="back-btn"
              onClick={() => setIsSignUp(false)}
            >
              {t('back')}
            </button>
          )}
          <h2>{isSignUp ? t('createAccount') : t('signIn')}</h2>
        </div>

        {/* Error/Success Messages */}
        {error && (
          <div style={{
            padding: '10px',
            backgroundColor: '#f8d7da',
            border: '1px solid #f5c6cb',
            borderRadius: '5px',
            color: '#721c24',
            marginBottom: '15px'
          }}>
            ❌ {error}
          </div>
        )}

        {success && (
          <div style={{
            padding: '10px',
            backgroundColor: '#d4edda',
            border: '1px solid #c3e6cb',
            borderRadius: '5px',
            color: '#155724',
            marginBottom: '15px'
          }}>
            ✅ {success}
          </div>
        )}
        
        <div className="social-row">
          <SocialButton 
            onClick={() => handleRoleChange('migrant')}
            isSelected={selectedRole === 'migrant'}
          >
            {t('migrant')}
          </SocialButton>
          <SocialButton 
            onClick={() => handleRoleChange('doctor')}
            isSelected={selectedRole === 'doctor'}
          >
            {t('doctor')}
          </SocialButton>
          <SocialButton 
            onClick={() => handleRoleChange('health')}
            isSelected={selectedRole === 'health'}
          >
            {t('healthOfficial')}
          </SocialButton>
        </div>

        {selectedRole && (
          <div className="input-group">
            <input 
              type="text" 
              required 
              value={formData.id}
              onChange={(e) => setFormData({...formData, id: e.target.value})}
              placeholder={selectedRole === 'migrant' ? t('abhaId') : t('healthProfessionalId')} 
              pattern={selectedRole === 'migrant' ? "[0-9]{14}" : "[A-Z0-9]{8}"}
              title={selectedRole === 'migrant' ? 
                t('validAbhaId') : 
                t('validHealthId')
              }
              maxLength={selectedRole === 'migrant' ? 14 : 8}
            />
          </div>
        )}

        {/* Show Full Name field only for signup */}
        {isSignUp && selectedRole !== 'migrant' && (
          <input 
            type="text" 
            placeholder={t('fullName')} 
            required 
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
          />
        )}

        <div className="input-group">
          {selectedRole === 'migrant' ? (
            <input 
              type="tel" 
              required 
              placeholder={t('phoneNumber')} 
              pattern="[0-9]{10}"
              value={formData.emailOrPhone}
              onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
            />
          ) : (
            <input 
              type="email" 
              required 
              placeholder={t('email')}
              value={formData.emailOrPhone}
              onChange={(e) => setFormData({...formData, emailOrPhone: e.target.value})}
            />
          )}
        </div>
        
        <input 
          type="password" 
          placeholder={t('password')}
          required
          value={formData.password}
          onChange={(e) => setFormData({...formData, password: e.target.value})}
        />
        {isSignUp && selectedRole !== 'migrant' && (
          <input 
            type="password" 
            placeholder={t('confirmPassword')} 
            required
            value={formData.confirmPassword}
            onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
          />
        )}

        <div style={{ display: 'flex', justifyContent: "left", alignItems: 'center', gap: '1.5rem' }}>
          {!isSignUp && (
            <a className="link-muted" href="#" onClick={(e) => {
              e.preventDefault();
              setShowOTP(true);
            }}>{t('forgotPassword')}</a>
          )}
          <button type="button" onClick={handleSubmit} className="btn primary">
            {isSignUp ? t('signUp') : t('signIn')}
          </button>
          {isSignUp && selectedRole !== 'migrant' && (
            <a 
              className="link-text" 
              href="https://www.nmc.org.in/registration/" 
              target="_blank"
              rel="noopener noreferrer"
            >
              {t('dontHaveHealthId')}
            </a>
          )}
        </div>

        {selectedRole === 'migrant' ? (
          <p className="switch-text">
            {t('dontHaveAbhaId')} <a className="link-text" href="https://abha.abdm.gov.in/abha/v3/register">{t('createOne')}</a>
          </p>
        ) : (
          <p className="switch-text">
            {isSignUp ? 
              t('alreadyHaveAccount') + " " : 
              t('dontHaveAccount') + " "
            }
            <span className="link-text" onClick={() => setIsSignUp(!isSignUp)}>
              {isSignUp ? t('signIn') : t('signUp')}
            </span>
          </p>
        )}
      </div>
      <img src={logo} height={400} alt="WellnessWeb Logo" />
    </div>
  );
}

// BubbleEffect component (simplified version)
function BubbleEffect() {
  return (
    <div className="bubble-container">
      {/* Bubbles will be added via CSS animations */}
    </div>
  );
}

export default function Authentication() {
  return (
    <div className="page-bg">
      <LanguageSelector />
      <BubbleEffect />
      <div className="auth-wrapper">
        <div className="container">
          <div className="form-wrap">
            <LoginForm />
          </div>
        </div>
      </div>
    </div>
  );
}