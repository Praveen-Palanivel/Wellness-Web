import React, { useState, useEffect } from "react";
import {
  Users,
  FileText,
  Download,
  CreditCard,
  Bell,
  QrCode,
  User,
  Edit3,
  Save,
  X
} from "lucide-react";

// Mock useLanguage hook
const useLanguage = () => {
  const [language, setLanguage] = useState("en");
  return { language, setLanguage };
};

const translations = {
  en: {
    title: "Health Official Dashboard",
    qrScan: "Scan QR",
    patientList: "Patient List",
    reports: "Reports",
    documents: "Documents",
    registrations: "Registrations",
    notifications: "Notifications",
    profile: "My Profile",
    profileSection: {
      personalDetails: "Personal Details",
      professionalDetails: "Professional Details",
      contactDetails: "Contact Details",
      name: "Name",
      age: "Age",
      gender: "Gender",
      qualification: "Qualification",
      specialization: "Specialization",
      experience: "Years of Experience",
      registrationNumber: "Government Registration Number",
      office: "Office/Department",
      designation: "Designation",
      jurisdiction: "Jurisdiction Area",
      email: "Email",
      phone: "Phone",
      address: "Address",
      emergencyContact: "Emergency Contact",
      edit: "Edit",
      save: "Save",
      cancel: "Cancel"
    }
  },
  hi: {
    title: "स्वास्थ्य अधिकारी डैशबोर्ड",
    qrScan: "क्यूआर स्कैन करें",
    patientList: "रोगी सूची",
    reports: "रिपोर्ट",
    documents: "दस्तावेज़",
    registrations: "पंजीकरण",
    notifications: "सूचनाएं",
    profile: "मेरी प्रोफाइल"
  },
  ta: {
    title: "ஆரோக்கிய அதிகாரி டாஷ்போர்டு",
    qrScan: "QR ஸ்கேன்",
    patientList: "நோயாளி பட்டியல்",
    reports: "அறிக்கைகள்",
    documents: "ஆவணங்கள்",
    registrations: "பதிவுகள்",
    notifications: "அறிவிப்புகள்",
    profile: "என் சுயவிவரம்"
  },
  ml: {
    title: "ആരോഗ്യ ഉദ്യോഗസ്ഥ ഡാഷ്ബോർഡ്",
    qrScan: "QR സ്കാൻ",
    patientList: "രോഗി ലിസ്റ്റ്",
    reports: "റിപ്പോർട്ടുകൾ",
    documents: "രേഖകൾ",
    registrations: "രജിസ്ട്രേഷനുകൾ",
    notifications: "അറിയിപ്പുകൾ",
    profile: "എന്റെ പ്രൊഫൈൽ"
  },
};

// Mock QR Scanner Component
const QRScanner = () => (
  <div style={{ padding: "2rem", backgroundColor: "#f8fafc", borderRadius: "12px", margin: "2rem auto", maxWidth: "500px" }}>
    <h3>QR Code Scanner</h3>
    <div style={{ 
      width: "300px", 
      height: "300px", 
      backgroundColor: "#e5e7eb", 
      margin: "1rem auto", 
      borderRadius: "8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#6b7280"
    }}>
      <QrCode size={64} />
      <span style={{ marginLeft: "1rem" }}>Scanner View</span>
    </div>
    <p>Point your camera at a patient's QR code to access their health records</p>
  </div>
);

export default function HealthOfficialHome() {
  const { language, setLanguage } = useLanguage();
  const [activeTab, setActiveTab] = useState("home");
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const [notificationsCount, setNotificationsCount] = useState(3);
  const [newRegistrationsCount, setNewRegistrationsCount] = useState(2);

  // Mock health official profile data
  const [officialProfile, setOfficialProfile] = useState({
    name: "Dr. Priya Nair",
    age: "42",
    gender: "Female",
    qualification: "MBBS, MPH",
    specialization: "Public Health",
    experience: "18",
    registrationNumber: "KGR789012",
    office: "District Health Office, Ernakulam",
    designation: "District Health Officer",
    jurisdiction: "Ernakulam District",
    email: "priya.nair@kerala.gov.in",
    phone: "+91 9123456789",
    address: "Health Department Complex, Kakkanad, Kochi",
    emergencyContact: "+91 9123456790"
  });

  const [profileFormData, setProfileFormData] = useState({ ...officialProfile });

  useEffect(() => {
    const interval = setInterval(() => {
      setNotificationsCount(prev => prev + Math.floor(Math.random() * 2));
      setNewRegistrationsCount(prev => prev + Math.floor(Math.random() * 1));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleProfileEdit = () => {
    setIsEditingProfile(true);
    setProfileFormData({ ...officialProfile });
  };

  const handleProfileSave = () => {
    setOfficialProfile({ ...profileFormData });
    setIsEditingProfile(false);
  };

  const handleProfileCancel = () => {
    setProfileFormData({ ...officialProfile });
    setIsEditingProfile(false);
  };

  const handleInputChange = (field, value) => {
    setProfileFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Profile Component
  const ProfileSection = () => (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "1rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h2 style={{ color: "#1f2937", margin: 0 }}>
          {translations[language]?.profile || "My Profile"}
        </h2>
        {!isEditingProfile ? (
          <button
            onClick={handleProfileEdit}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              padding: "0.5rem 1rem",
              backgroundColor: "#3b82f6",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer"
            }}
          >
            <Edit3 size={16} />
            {translations[language]?.profileSection?.edit || "Edit"}
          </button>
        ) : (
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              onClick={handleProfileSave}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#10b981",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer"
              }}
            >
              <Save size={16} />
              {translations[language]?.profileSection?.save || "Save"}
            </button>
            <button
              onClick={handleProfileCancel}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#ef4444",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer"
              }}
            >
              <X size={16} />
              {translations[language]?.profileSection?.cancel || "Cancel"}
            </button>
          </div>
        )}
      </div>

      {/* Personal Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem", marginBottom: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.personalDetails || "Personal Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.name || "Name"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.name}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.age || "Age"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.age}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.gender || "Gender"}
            </label>
            {isEditingProfile ? (
              <select
                value={profileFormData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.gender}</p>
            )}
          </div>
        </div>
      </div>

      {/* Professional Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem", marginBottom: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.professionalDetails || "Professional Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.qualification || "Qualification"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.qualification}
                onChange={(e) => handleInputChange('qualification', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.qualification}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.specialization || "Specialization"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.specialization}
                onChange={(e) => handleInputChange('specialization', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.specialization}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.experience || "Years of Experience"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.experience}
                onChange={(e) => handleInputChange('experience', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.experience} years</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.registrationNumber || "Government Registration Number"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.registrationNumber}
                onChange={(e) => handleInputChange('registrationNumber', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.registrationNumber}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.office || "Office/Department"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.office}
                onChange={(e) => handleInputChange('office', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.office}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.designation || "Designation"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.designation}
                onChange={(e) => handleInputChange('designation', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.designation}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.jurisdiction || "Jurisdiction Area"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.jurisdiction}
                onChange={(e) => handleInputChange('jurisdiction', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.jurisdiction}</p>
            )}
          </div>
        </div>
      </div>

      {/* Contact Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.contactDetails || "Contact Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.email || "Email"}
            </label>
            {isEditingProfile ? (
              <input
                type="email"
                value={profileFormData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.email}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.phone || "Phone"}
            </label>
            {isEditingProfile ? (
              <input
                type="tel"
                value={profileFormData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.phone}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.emergencyContact || "Emergency Contact"}
            </label>
            {isEditingProfile ? (
              <input
                type="tel"
                value={profileFormData.emergencyContact}
                onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.emergencyContact}</p>
            )}
          </div>
          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.address || "Address"}
            </label>
            {isEditingProfile ? (
              <textarea
                value={profileFormData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px", minHeight: "60px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{officialProfile.address}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const headerStyle = {
    backgroundColor: "#2563eb",
    color: "white",
    padding: "1rem 2rem",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  };

  const navBarStyle = {
    backgroundColor: "#f8fafc",
    borderBottom: "1px solid #e2e8f0",
    padding: "0",
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    flexWrap: "wrap",
  };

  const navItemStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "1rem 0.5rem",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
    minWidth: "120px",
    textAlign: "center",
    border: "none",
    backgroundColor: "transparent",
    color: "#374151",
    fontSize: "0.875rem",
    fontWeight: "500",
    position: "relative",
  };

  const navItemHover = "#e2e8f0";

  const renderContent = () => {
    switch (activeTab) {
      case "qrScan": return <QRScanner />;
      case "patientList": return <p>List of patients will appear here</p>;
      case "reports": return <p>Reports will appear here</p>;
      case "documents": return <p>Uploaded documents will appear here</p>;
      case "registrations": return <p>{newRegistrationsCount} New registrations will appear here</p>;
      case "notifications": return <p>{notificationsCount} New notifications will appear here</p>;
      case "profile": return <ProfileSection />;
      default: return (
        <>
          <h2>Welcome, Health Official</h2>
          <p>Select an option from the navigation bar above to get started.</p>
        </>
      );
    }
  };

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#fff" }}>
      {/* Header without language selector */}
      <div style={headerStyle}>
        <h1 style={{ margin: 0 }}>{translations[language]?.title || translations.en.title}</h1>
      </div>

      {/* Navigation Bar */}
      <div style={navBarStyle}>
        <button
          style={navItemStyle}
          onClick={() => setActiveTab("qrScan")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <QrCode size={24} style={{ marginBottom: "0.5rem", color: "#10b981" }} />
          <span>{translations[language]?.qrScan || translations.en.qrScan}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("profile")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <User size={24} style={{ marginBottom: "0.5rem", color: "#3b82f6" }} />
          <span>{translations[language]?.profile || translations.en.profile}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("patientList")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Users size={24} style={{ marginBottom: "0.5rem", color: "#10b981" }} />
          <span>{translations[language]?.patientList || translations.en.patientList}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("reports")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <FileText size={24} style={{ marginBottom: "0.5rem", color: "#3b82f6" }} />
          <span>{translations[language]?.reports || translations.en.reports}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("documents")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Download size={24} style={{ marginBottom: "0.5rem", color: "#6366f1" }} />
          <span>{translations[language]?.documents || translations.en.documents}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("registrations")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <CreditCard size={24} style={{ marginBottom: "0.5rem", color: "#8b5cf6" }} />
          <span>{translations[language]?.registrations || translations.en.registrations}</span>
          {newRegistrationsCount > 0 && (
            <span style={{
              position: "absolute",
              top: "0.5rem",
              right: "0.5rem",
              backgroundColor: "#ef4444",
              color: "white",
              borderRadius: "50%",
              width: "20px",
              height: "20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "0.75rem"
            }}>{newRegistrationsCount}</span>
          )}
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("notifications")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Bell size={24} style={{ marginBottom: "0.5rem", color: "#ef4444" }} />
          <span>{translations[language]?.notifications || translations.en.notifications}</span>
          {notificationsCount > 0 && (
            <span style={{
              position: "absolute",
              top: "0.5rem",
              right: "0.5rem",
              backgroundColor: "#ef4444",
              color: "white",
              borderRadius: "50%",
              width: "20px",
              height: "20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "0.75rem"
            }}>{notificationsCount}</span>
          )}
        </button>
      </div>

      {/* Main Content */}
      <div style={{ padding: "2rem", textAlign: "center" }}>{renderContent()}</div>
    </div>
  );
}