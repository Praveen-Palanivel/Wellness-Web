import React, { useState } from "react";
import {
  QrCode,
  FileText,
  Syringe,
  Activity,
  Clock,
  Bell,
  User,
  Edit3,
  Save,
  X
} from "lucide-react";

const useLanguage = () => {
  const [language, setLanguage] = useState('en');
  return { language, setLanguage };
};

const translations = {
  en: {
    title: "Doctor Dashboard",
    scan: "Scan QR",
    summary: "Patient Summary",
    vaccinations: "Vaccinations",
    vitals: "Observations / Vitals",
    history: "History",
    notifications: "Notifications",
    profile: "My Profile",
    profileSection: {
      personalDetails: "Personal Details",
      professionalDetails: "Professional Details",
      contactDetails: "Contact Details",
      name: "Name",
      age: "Age",
      gender: "Gender",
      qualification: "Qualification",
      specialization: "Specialization",
      experience: "Years of Experience",
      registrationNumber: "Medical Registration Number",
      hospital: "Hospital/Clinic",
      department: "Department",
      designation: "Designation",
      email: "Email",
      phone: "Phone",
      address: "Address",
      emergencyContact: "Emergency Contact",
      edit: "Edit",
      save: "Save",
      cancel: "Cancel"
    }
  },
  hi: {
    title: "डॉक्टर डैशबोर्ड",
    scan: "क्यूआर स्कैन करें",
    summary: "रोगी सारांश",
    vaccinations: "टीकाकरण",
    vitals: "निरीक्षण / महत्वपूर्ण लक्षण",
    history: "इतिहास",
    notifications: "सूचनाएं",
    profile: "मेरी प्रोफाइल"
  },
  ta: {
    title: "மருத்துவர் டாஷ்போர்டு",
    scan: "QR ஸ்கேன்",
    summary: "நோயாளி சுருக்கம்",
    vaccinations: "தடுப்பூசிகள்",
    vitals: "கண்காணிப்புகள் / உயிர்க்குறிகள்",
    history: "வரலாறு",
    notifications: "அறிவிப்புகள்",
    profile: "என் சுயவிவரம்"
  },
  ml: {
    title: "ഡോക്ടർ ഡാഷ്ബോർഡ്",
    scan: "QR സ്കാൻ",
    summary: "രോഗി സംഗ്രഹം",
    vaccinations: "വാക്സിനേഷനുകൾ",
    vitals: "നിരീക്ഷണങ്ങൾ / വൈറ്റൽസ്",
    history: "ചരിത്രം",
    notifications: "അറിയിപ്പുകൾ",
    profile: "എന്റെ പ്രൊഫൈൽ"
  },
};

// Mock QR Scanner Component
const QRScanner = () => (
  <div style={{ padding: "2rem", backgroundColor: "#f8fafc", borderRadius: "12px", margin: "2rem auto", maxWidth: "500px" }}>
    <h3>QR Code Scanner</h3>
    <div style={{ 
      width: "300px", 
      height: "300px", 
      backgroundColor: "#e5e7eb", 
      margin: "1rem auto", 
      borderRadius: "8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#6b7280"
    }}>
      <QrCode size={64} />
      <span style={{ marginLeft: "1rem" }}>Scanner View</span>
    </div>
    <p>Point your camera at a patient's QR code to access their health records</p>
  </div>
);

export default function DoctorHome() {
  const { language, setLanguage } = useLanguage();
  const [activeTab, setActiveTab] = useState("home");
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Mock doctor profile data
  const [doctorProfile, setDoctorProfile] = useState({
    name: "Dr. Rajesh Kumar",
    age: "45",
    gender: "Male",
    qualification: "MBBS, MD",
    specialization: "Internal Medicine",
    experience: "20",
    registrationNumber: "KMC123456",
    hospital: "Kerala Medical College Hospital",
    department: "General Medicine",
    designation: "Senior Consultant",
    email: "dr.rajesh@kmc.in",
    phone: "+91 9876543210",
    address: "123 Medical Colony, Kochi, Kerala",
    emergencyContact: "+91 9876543211"
  });

  const [profileFormData, setProfileFormData] = useState({ ...doctorProfile });

  const handleProfileEdit = () => {
    setIsEditingProfile(true);
    setProfileFormData({ ...doctorProfile });
  };

  const handleProfileSave = () => {
    setDoctorProfile({ ...profileFormData });
    setIsEditingProfile(false);
  };

  const handleProfileCancel = () => {
    setProfileFormData({ ...doctorProfile });
    setIsEditingProfile(false);
  };

  const handleInputChange = (field, value) => {
    setProfileFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Profile Component
  const ProfileSection = () => (
    <div style={{ maxWidth: "800px", margin: "0 auto", padding: "1rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <h2 style={{ color: "#1f2937", margin: 0 }}>
          {translations[language]?.profile || "My Profile"}
        </h2>
        {!isEditingProfile ? (
          <button
            onClick={handleProfileEdit}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              padding: "0.5rem 1rem",
              backgroundColor: "#3b82f6",
              color: "white",
              border: "none",
              borderRadius: "6px",
              cursor: "pointer"
            }}
          >
            <Edit3 size={16} />
            {translations[language]?.profileSection?.edit || "Edit"}
          </button>
        ) : (
          <div style={{ display: "flex", gap: "0.5rem" }}>
            <button
              onClick={handleProfileSave}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#10b981",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer"
              }}
            >
              <Save size={16} />
              {translations[language]?.profileSection?.save || "Save"}
            </button>
            <button
              onClick={handleProfileCancel}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.5rem 1rem",
                backgroundColor: "#ef4444",
                color: "white",
                border: "none",
                borderRadius: "6px",
                cursor: "pointer"
              }}
            >
              <X size={16} />
              {translations[language]?.profileSection?.cancel || "Cancel"}
            </button>
          </div>
        )}
      </div>

      {/* Personal Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem", marginBottom: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.personalDetails || "Personal Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.name || "Name"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.name}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.age || "Age"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.age}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.gender || "Gender"}
            </label>
            {isEditingProfile ? (
              <select
                value={profileFormData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.gender}</p>
            )}
          </div>
        </div>
      </div>

      {/* Professional Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem", marginBottom: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.professionalDetails || "Professional Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.qualification || "Qualification"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.qualification}
                onChange={(e) => handleInputChange('qualification', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.qualification}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.specialization || "Specialization"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.specialization}
                onChange={(e) => handleInputChange('specialization', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.specialization}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.experience || "Years of Experience"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.experience}
                onChange={(e) => handleInputChange('experience', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.experience} years</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.registrationNumber || "Medical Registration Number"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.registrationNumber}
                onChange={(e) => handleInputChange('registrationNumber', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.registrationNumber}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.hospital || "Hospital/Clinic"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.hospital}
                onChange={(e) => handleInputChange('hospital', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.hospital}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.department || "Department"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.department}
                onChange={(e) => handleInputChange('department', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.department}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.designation || "Designation"}
            </label>
            {isEditingProfile ? (
              <input
                type="text"
                value={profileFormData.designation}
                onChange={(e) => handleInputChange('designation', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.designation}</p>
            )}
          </div>
        </div>
      </div>

      {/* Contact Details Section */}
      <div style={{ backgroundColor: "#f8fafc", borderRadius: "12px", padding: "1.5rem" }}>
        <h3 style={{ color: "#4a5568", marginBottom: "1rem", backgroundColor: "#dbeafe", padding: "0.5rem", borderRadius: "6px" }}>
          {translations[language]?.profileSection?.contactDetails || "Contact Details"}
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: "1rem" }}>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.email || "Email"}
            </label>
            {isEditingProfile ? (
              <input
                type="email"
                value={profileFormData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.email}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.phone || "Phone"}
            </label>
            {isEditingProfile ? (
              <input
                type="tel"
                value={profileFormData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.phone}</p>
            )}
          </div>
          <div>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.emergencyContact || "Emergency Contact"}
            </label>
            {isEditingProfile ? (
              <input
                type="tel"
                value={profileFormData.emergencyContact}
                onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.emergencyContact}</p>
            )}
          </div>
          <div style={{ gridColumn: "1 / -1" }}>
            <label style={{ display: "block", fontWeight: "500", marginBottom: "0.5rem" }}>
              {translations[language]?.profileSection?.address || "Address"}
            </label>
            {isEditingProfile ? (
              <textarea
                value={profileFormData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                style={{ width: "100%", padding: "0.5rem", border: "1px solid #d1d5db", borderRadius: "4px", minHeight: "60px" }}
              />
            ) : (
              <p style={{ margin: 0, padding: "0.5rem 0" }}>{doctorProfile.address}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const headerStyle = {
    backgroundColor: "#2563eb",
    color: "white",
    padding: "1rem 2rem",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  };

  const navBarStyle = {
    backgroundColor: "#f8fafc",
    borderBottom: "1px solid #e2e8f0",
    padding: "0",
    display: "flex",
    justifyContent: "space-around",
    alignItems: "center",
    flexWrap: "wrap",
  };

  const navItemStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "1rem 0.5rem",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
    minWidth: "120px",
    textAlign: "center",
    border: "none",
    backgroundColor: "transparent",
    color: "#374151",
    fontSize: "0.875rem",
    fontWeight: "500",
  };

  const navItemHover = "#e2e8f0";

  const renderContent = () => {
    switch (activeTab) {
      case "qr":
        return <QRScanner />;
      case "summary":
        return <p>📑 Patient Summary details go here</p>;
      case "vaccinations":
        return <p>💉 Vaccination records go here</p>;
      case "vitals":
        return <p>📊 Observations and Vitals go here</p>;
      case "history":
        return <p>🕒 Medical history goes here</p>;
      case "notifications":
        return <p>🔔 Notifications will appear here</p>;
      case "profile":
        return <ProfileSection />;
      default:
        return (
          <>
            <h2>Welcome, Doctor</h2>
            <p>Select an option from the navigation bar above to get started.</p>
          </>
        );
    }
  };

  return (
    <div style={{ minHeight: "100vh", backgroundColor: "#fff" }}>
      {/* Header */}
      <div style={headerStyle}>
        <h1 style={{ margin: 0 }}>{translations[language]?.title || translations.en.title}</h1>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          style={{
            padding: "0.5rem",
            borderRadius: "4px",
            border: "1px solid #ccc",
            backgroundColor: "white",
            color: "#333",
          }}
        >
          <option value="en">English</option>
          <option value="hi">हिन्दी</option>
          <option value="ta">தமிழ்</option>
          <option value="ml">മലയാളം</option>
        </select>
      </div>

      {/* Navigation Bar */}
      <div style={navBarStyle}>
        <button
          style={navItemStyle}
          onClick={() => setActiveTab("qr")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <QrCode size={24} style={{ marginBottom: "0.5rem", color: "#10b981" }} />
          <span>{translations[language]?.scan || translations.en.scan}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("profile")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <User size={24} style={{ marginBottom: "0.5rem", color: "#3b82f6" }} />
          <span>{translations[language]?.profile || translations.en.profile}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("summary")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <FileText size={24} style={{ marginBottom: "0.5rem", color: "#3b82f6" }} />
          <span>{translations[language]?.summary || translations.en.summary}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("vaccinations")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Syringe size={24} style={{ marginBottom: "0.5rem", color: "#6366f1" }} />
          <span>{translations[language]?.vaccinations || translations.en.vaccinations}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("vitals")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Activity size={24} style={{ marginBottom: "0.5rem", color: "#8b5cf6" }} />
          <span>{translations[language]?.vitals || translations.en.vitals}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("history")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Clock size={24} style={{ marginBottom: "0.5rem", color: "#f59e0b" }} />
          <span>{translations[language]?.history || translations.en.history}</span>
        </button>

        <button
          style={navItemStyle}
          onClick={() => setActiveTab("notifications")}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = navItemHover)}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
        >
          <Bell size={24} style={{ marginBottom: "0.5rem", color: "#ef4444" }} />
          <span>{translations[language]?.notifications || translations.en.notifications}</span>
        </button>
      </div>

      {/* Main Content */}
      <div style={{ padding: "2rem", textAlign: "center" }}>{renderContent()}</div>
    </div>
  );
}